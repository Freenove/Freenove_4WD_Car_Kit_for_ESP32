var searchData=
[
  ['panasonic_5fac_5fremote_5fmodel_5ft_7308',['panasonic_ac_remote_model_t',['../IRsend_8h.html#a1b797a5e5176ac0eef49810bf7f40e6f',1,'IRsend.h']]]
];
