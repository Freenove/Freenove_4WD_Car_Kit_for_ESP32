var searchData=
[
  ['uint64tostring_3654',['uint64ToString',['../IRutils_8cpp.html#a9f6ddef74b41ef6f8d2805fcfc396420',1,'uint64ToString(uint64_t input, uint8_t base):&#160;IRutils.cpp'],['../IRutils_8h.html#a781650451d38303e80da677539f574ee',1,'uint64ToString(uint64_t input, uint8_t base=10):&#160;IRutils.cpp']]],
  ['uint8tobcd_3655',['uint8ToBcd',['../namespaceirutils.html#a534704a52b75acd46f687cc0a2b91bf1',1,'irutils']]],
  ['unknown_3656',['unknown',['../unionHaierProtocol.html#aabc2a684c5936858544c02ec8a68afb9',1,'HaierProtocol::unknown()'],['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fada6ce26a62afab55d7606ad4e92428b30c',1,'UNKNOWN():&#160;IRremoteESP8266.h']]],
  ['unknown1_3657',['unknown1',['../unionGreeProtocol.html#ae973c1c723b7162959374e1fd8ecab61',1,'GreeProtocol']]],
  ['unknown2_3658',['unknown2',['../unionGreeProtocol.html#aa102f7d68c26f5b8644b13113a5b05f4',1,'GreeProtocol']]],
  ['unused_3659',['UNUSED',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fadaa09b651ef326a9d8efcee5cc5b720ab4',1,'IRremoteESP8266.h']]],
  ['updatesavedstate_3660',['updateSavedState',['../classIRCoolixAC.html#a1f39630b328939307bb08c18e56e9ad3',1,'IRCoolixAC']]],
  ['use_5ftime_5fstate_3661',['use_time_state',['../classIRVestelAc.html#af1b622c50a4952fb3edaf483e1bf9328',1,'IRVestelAc']]],
  ['used_3662',['used',['../structmatch__result__t.html#a26cea305aa83ed65b88ac0b6ed6de54a',1,'match_result_t']]],
  ['usefahrenheit_3663',['UseFahrenheit',['../unionGreeProtocol.html#a47c79761efe40c00e6bb01b7712b272c',1,'GreeProtocol::UseFahrenheit()'],['../unionMideaProtocol.html#a1b1258107620bb83fd6356815242e19b',1,'MideaProtocol::useFahrenheit()']]]
];
