var searchData=
[
  ['xfan_3678',['Xfan',['../unionGreeProtocol.html#a3fbf66dfc2043710c5e00f8230eddb48',1,'GreeProtocol']]],
  ['xorbytes_3679',['xorBytes',['../IRutils_8cpp.html#aaa2a3fb714375e61051a0b24623b9cc9',1,'xorBytes(const uint8_t *const start, const uint16_t length, const uint8_t init):&#160;IRutils.cpp'],['../IRutils_8h.html#ab030689a93499311ee8e6621ac8757aa',1,'xorBytes(const uint8_t *const start, const uint16_t length, const uint8_t init=0):&#160;IRutils.cpp']]]
];
